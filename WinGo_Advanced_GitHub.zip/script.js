let timeLeft = 60;
let timerInterval;
let balance = localStorage.getItem("balance") ? parseInt(localStorage.getItem("balance")) : 100;
let history = JSON.parse(localStorage.getItem("history")) || [];

document.getElementById("balance").textContent = balance;
document.getElementById("countdown").textContent = timeLeft;
renderHistory();

startTimer();

function startTimer() {
  timerInterval = setInterval(() => {
    timeLeft--;
    document.getElementById("countdown").textContent = timeLeft;
    if (timeLeft <= 0) {
      clearInterval(timerInterval);
      resolveBet();
      timeLeft = 60;
      startTimer();
    }
  }, 1000);
}

let currentBet = null;
function placeBet(type) {
  const amount = parseInt(document.getElementById("betAmount").value);
  if (!amount || amount <= 0 || amount > balance) {
    alert("Enter valid bet amount");
    return;
  }
  currentBet = { type, amount };
  alert(`Bet placed: ${type} with ${amount} coins`);
}

function resolveBet() {
  const result = Math.floor(Math.random() * 10);
  const color = getColor(result);
  const size = result < 5 ? 'Small' : 'Big';

  let message = `Result: ${result} (${size}, ${color})`;
  document.getElementById("lastResult").textContent = message;

  if (currentBet) {
    if (currentBet.type === size) {
      balance += currentBet.amount;
      message += " - You WON!";
    } else {
      balance -= currentBet.amount;
      message += " - You LOST.";
    }
    currentBet = null;
  }

  document.getElementById("balance").textContent = balance;
  localStorage.setItem("balance", balance);

  history.unshift(message);
  if (history.length > 10) history.pop();
  localStorage.setItem("history", JSON.stringify(history));
  renderHistory();
}

function getColor(num) {
  if (num === 0 || num === 5) return "Violet";
  return num % 2 === 0 ? "Red" : "Green";
}

function renderHistory() {
  const list = document.getElementById("historyList");
  list.innerHTML = "";
  history.forEach(item => {
    const li = document.createElement("li");
    li.textContent = item;
    list.appendChild(li);
  });
}